__author__ = "John Evans"
__copyright__ = "Copyright 2024, John Evans"
__credits__ = ["John Evans"]
__license__ = "GPLv3"
__version__ = "0.2.0"
__maintainer__ = "John Evans"
__email__ = "john.p.evans@state.co.us"
__status__ = "Development"